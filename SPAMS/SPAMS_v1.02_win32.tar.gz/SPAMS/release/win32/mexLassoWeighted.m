% 
% Usage:   alpha=mexLassoWeighted(X,D,W,param);
%
% Name: mexLassoWeighted.  
%
% WARNING: This function has not been tested intensively
%
% Description: mexLassoWeighted is an efficient implementation of the
%     LARS algorithm for solving the weighted Lasso. It is optimized
%     for solving a large number of small or medium-sized 
%     decomposition problem (and not for a single large one).
%     It first computes the Gram matrix D'D and then perform
%     a Cholesky-based OMP of the input signals in parallel.
%     It aims at addressing the following problems
%     for all columns x_i of X, 
%       1) when param.mode=0
%         min_{alpha_i} ||x_i-Dalpha_i||_2^2   s.t.  
%                                     ||diag(w_i)alpha_i||_1 <= lambda
%       2) when param.mode=1
%         min_{alpha_i} ||diag(w_i)alpha_i||_1  s.t.
%                                        ||x_i-Dalpha_i||_2^2 <= lambda
%       3) when param.mode=2
%         min_{alpha_i} 0.5||x_i-Dalpha_i||_2^2  +  
%                                         lambda||diag(w_i)alpha_i||_1 
%     Eventually, when param.pos=true, it solves the previous problems
%     with positivity constraints on the vectors alpha_i
%
% Inputs: X:  double m x n matrix   (input signals)
%               m is the signal size
%               n is the number of signals to decompose
%         D:  double m x p matrix   (dictionary)
%               p is the number of elements in the dictionary
%         W:  double p x n matrix   (weights)
%         param: struct
%            param.lambda  (parameter)
%            param.L (optional, maximum number of elements of each 
%            decomposition)
%            param.pos (optional, adds positivity constraints on the
%            coefficients, false by default)
%            param.mode (see above, by default: 2)
%            param.numThreads (optional, number of threads for exploiting
%            multi-core / multi-cpus. By default, it takes the value -1,
%            which automatically selects all the available CPUs/cores).
%
% Output: alpha: double sparse p x n matrix (output coefficients)
%
% Note: this function admits a few experimental usages, which have not
%     been extensively tested:
%         - single precision setting (even though the output alpha is double 
%           precision)
%
% Author: Julien Mairal, 2009


